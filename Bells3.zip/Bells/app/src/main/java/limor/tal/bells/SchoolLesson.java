package limor.tal.bells;

public class SchoolLesson {
    private int day;
    private int lessonNumber;
    private String subject;
    private String startTime;
    private String endTime;
    private String teacherGroup;
    private String teacherPhotoPath;

    public SchoolLesson(int day, int lessonNumber, String subject, String startTime, String endTime, String teacherGroup, String teacherPhotoPath) {
        this.day = day;
        this.lessonNumber = lessonNumber;
        this.subject = subject;
        this.startTime = startTime;
        this.endTime = endTime;
        this.teacherGroup = teacherGroup;
        this.teacherPhotoPath = teacherPhotoPath;
    }

    public int getDay() { return day; }
    public int getLessonNumber() { return lessonNumber; }
    public String getSubject() { return subject; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public String getTeacherGroup() { return teacherGroup; }
    public String getTeacherPhotoPath() { return teacherPhotoPath; }
}