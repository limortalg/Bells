package limor.tal.bells;

public class SchoolLesson {
    private int day;
    private int lessonNumber;
    private String startTime;
    private String endTime;
    private boolean isLocked;
    private int breakDuration;

    public SchoolLesson(int day, int lessonNumber, String startTime, String endTime, boolean isLocked, int breakDuration) {
        this.day = day;
        this.lessonNumber = lessonNumber;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isLocked = isLocked;
        this.breakDuration = breakDuration;
    }

    public int getDay() {
        return day;
    }

    public int getLessonNumber() {
        return lessonNumber;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public int getBreakDuration() {
        return breakDuration;
    }
}
