package limor.tal.bells;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ScheduleFragment extends Fragment implements ScheduleAdapter.OnSpeechClickListener,
        ScheduleAdapter.OnCameraClickListener, ScheduleAdapter.OnGalleryClickListener {

    private SchoolDatabaseHelper db;
    private int currentDay;
    private int totalDays;
    private String userType;
    private ScheduleAdapter adapter;
    private int currentLessonPosition;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            db = ((MainActivity) getActivity()).getDbHelper();
        }
        if (getArguments() != null) {
            currentDay = getArguments().getInt("currentDay", 1);
            totalDays = getArguments().getInt("totalDays", 5);
            userType = getArguments().getString("userType", "student");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.schedule_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        int maxLessons = getMaxLessons();
        List<Lesson> lessons = loadExistingSchedule(maxLessons);
        adapter = new ScheduleAdapter(requireContext(), lessons, this, this, this);
        recyclerView.setAdapter(adapter);

        Button saveButton = view.findViewById(R.id.save_schedule_button);
        Button nextDayButton = view.findViewById(R.id.next_day_button);

        saveButton.setOnClickListener(v -> saveSchedule());
        nextDayButton.setOnClickListener(v -> {
            saveSchedule();
            if (currentDay < totalDays) {
                ScheduleFragment nextFragment = new ScheduleFragment();
                Bundle args = new Bundle();
                args.putInt("currentDay", currentDay + 1);
                args.putInt("totalDays", totalDays);
                args.putString("userType", userType);
                nextFragment.setArguments(args);
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, nextFragment)
                        .commit();
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).updateCurrentFragment(nextFragment);
                }
            } else {
                DashboardFragment dashboardFragment = new DashboardFragment();
                Bundle args = new Bundle();
                args.putString("userType", userType);
                dashboardFragment.setArguments(args);
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, dashboardFragment)
                        .commit();
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).updateCurrentFragment(dashboardFragment);
                }
            }
        });

        return view;
    }

    private List<Lesson> loadExistingSchedule(int maxLessons) {
        List<Lesson> lessons = new ArrayList<>();
        List<Lesson> existingLessons = ScheduleManager.getLessonsForDay(db, currentDay);
        for (int i = 1; i <= maxLessons; i++) {
            Lesson lesson = null;
            for (Lesson existing : existingLessons) {
                if (existing.getLessonNumber() == i) {
                    lesson = existing;
                    break;
                }
            }
            if (lesson == null) {
                lesson = new Lesson(currentDay, i, "", "", "", "", null);
            }
            lessons.add(lesson);
        }
        return lessons;
    }

    private void saveSchedule() {
        SQLiteDatabase dbWritable = db.getWritableDatabase();
        List<Lesson> lessons = adapter.getLessons();
        for (Lesson lesson : lessons) {
            String subject = lesson.getSubject();
            String teacherOrGroup = lesson.getTeacherOrGroup();
            String building = lesson.getBuilding();
            String room = lesson.getRoom();
            Bitmap photo = lesson.getPhoto();

            if (!subject.isEmpty() && !teacherOrGroup.isEmpty() && !building.isEmpty() && !room.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put("day", currentDay);
                values.put("lesson_number", lesson.getLessonNumber());
                values.put("subject", subject);
                values.put("teacher_or_group", teacherOrGroup);
                values.put("building", building);
                values.put("room", room);
                if (photo != null) {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    photo.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    values.put("photo", stream.toByteArray());
                }
                dbWritable.insertWithOnConflict("personal_schedule", null, values, SQLiteDatabase.CONFLICT_REPLACE);
            } else {
                dbWritable.delete("personal_schedule", "day = ? AND lesson_number = ?",
                        new String[]{String.valueOf(currentDay), String.valueOf(lesson.getLessonNumber())});
            }
        }
        // Schedule notifications after saving
        ScheduleManager.scheduleNotifications(requireContext(), db);
    }

    private int getMaxLessons() {
        int maxLessons = 0;
        for (int day = 1; day <= totalDays; day++) {
            int lessonCount = ScheduleManager.getSchoolLessons(db, day).size();
            if (lessonCount > maxLessons) {
                maxLessons = lessonCount;
            }
        }
        return maxLessons > 0 ? maxLessons : 10;
    }

    @Override
    public void onSpeechClick(int position) {
        currentLessonPosition = position;
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setCurrentLessonPosition(position);
            ((MainActivity) getActivity()).requestSpeechRecognition();
        }
    }

    @Override
    public void onCameraClick(int position) {
        currentLessonPosition = position;
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setCurrentLessonPosition(position);
            ((MainActivity) getActivity()).requestCamera();
        }
    }

    @Override
    public void onGalleryClick(int position) {
        currentLessonPosition = position;
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setCurrentLessonPosition(position);
            ((MainActivity) getActivity()).requestGallery();
        }
    }

    public void setTeacherPhotoForLesson(int position, Bitmap photo) {
        adapter.updatePhoto(position, photo);
        saveSchedule(); // Save immediately to persist photo
    }

    public void setSpeechResult(String result) {
        Lesson lesson = adapter.getLessons().get(currentLessonPosition);
        lesson.setTeacherOrGroup(result);
        adapter.notifyItemChanged(currentLessonPosition);
    }
}