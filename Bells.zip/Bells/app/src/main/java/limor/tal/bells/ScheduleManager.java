package limor.tal.bells;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ScheduleManager {

    public static List<SchoolLesson> getSchoolLessons(SchoolDatabaseHelper dbHelper, int day) {
        List<SchoolLesson> lessons = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        for (int lessonNum = 1; lessonNum <= 10; lessonNum++) {
            String configured = dbHelper.getSettings("lesson_" + lessonNum + "_locked", "false");
            boolean isLocked = "true".equals(configured);
            if (isLocked) {
                String startHour = dbHelper.getSettings("lesson_" + lessonNum + "_start_hour", "0");
                String startMinute = dbHelper.getSettings("lesson_" + lessonNum + "_start_minute", "0");
                String endHour = dbHelper.getSettings("lesson_" + lessonNum + "_end_hour", "0");
                String endMinute = dbHelper.getSettings("lesson_" + lessonNum + "_end_minute", "0");
                String startTime = String.format("%02d:%02d", Integer.parseInt(startHour), Integer.parseInt(startMinute));
                String endTime = String.format("%02d:%02d", Integer.parseInt(endHour), Integer.parseInt(endMinute));
                String breakDurationStr = dbHelper.getSettings("lesson_" + lessonNum + "_break_duration", "0");
                int breakDuration = Integer.parseInt(breakDurationStr);
                lessons.add(new SchoolLesson(day, lessonNum, startTime, endTime, isLocked, breakDuration));
            }
        }
        return lessons;
    }

    public static List<Lesson> getLessonsForDay(SchoolDatabaseHelper dbHelper, int day) {
        List<Lesson> lessons = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("personal_schedule",
                new String[]{"day", "lesson_number", "subject", "teacher_or_group", "building", "room", "photo"},
                "day = ?", new String[]{String.valueOf(day)},
                null, null, "lesson_number ASC");
        while (cursor.moveToNext()) {
            int lessonNumber = cursor.getInt(cursor.getColumnIndexOrThrow("lesson_number"));
            String subject = cursor.getString(cursor.getColumnIndexOrThrow("subject"));
            String teacherOrGroup = cursor.getString(cursor.getColumnIndexOrThrow("teacher_or_group"));
            String building = cursor.getString(cursor.getColumnIndexOrThrow("building"));
            String room = cursor.getString(cursor.getColumnIndexOrThrow("room"));
            byte[] photoBytes = cursor.getBlob(cursor.getColumnIndexOrThrow("photo"));
            Bitmap photo = photoBytes != null ? BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.length) : null;
            lessons.add(new Lesson(day, lessonNumber, subject, teacherOrGroup, building, room, photo));
        }
        cursor.close();
        return lessons;
    }

    public static void scheduleNotifications(Context context, SchoolDatabaseHelper dbHelper) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        String userType = dbHelper.getSettings("user_type", "student");
        int totalDays = Integer.parseInt(dbHelper.getSettings("total_days", "5"));

        for (int day = 1; day <= totalDays; day++) {
            List<SchoolLesson> schoolLessons = getSchoolLessons(dbHelper, day);
            List<Lesson> personalLessons = getLessonsForDay(dbHelper, day);

            for (SchoolLesson schoolLesson : schoolLessons) {
                int lessonNumber = schoolLesson.getLessonNumber();
                Lesson personalLesson = null;
                for (Lesson lesson : personalLessons) {
                    if (lesson.getLessonNumber() == lessonNumber) {
                        personalLesson = lesson;
                        break;
                    }
                }

                // Schedule lesson start notification
                String[] startTimeParts = schoolLesson.getStartTime().split(":");
                int startHour = Integer.parseInt(startTimeParts[0]);
                int startMinute = Integer.parseInt(startTimeParts[1]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.DAY_OF_WEEK, day == 1 ? Calendar.SUNDAY : day); // Sunday-based week
                calendar.set(Calendar.HOUR_OF_DAY, startHour);
                calendar.set(Calendar.MINUTE, startMinute);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);

                // Adjust for next week if time has passed
                if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
                    calendar.add(Calendar.DAY_OF_YEAR, 7);
                }

                Intent intent = new Intent(context, NotificationReceiver.class);
                intent.putExtra("notification_type", "lesson_start");
                intent.putExtra("lesson_number", lessonNumber);
                if (personalLesson != null) {
                    intent.putExtra("subject", personalLesson.getSubject());
                    intent.putExtra("teacher_or_group", personalLesson.getTeacherOrGroup());
                    intent.putExtra("building", personalLesson.getBuilding());
                    intent.putExtra("room", personalLesson.getRoom());
                }
                intent.putExtra("user_type", userType);
                intent.putExtra("ringtone_uri", dbHelper.getSettings("ringtone_uri", null));

                int requestCode = (day * 1000 + lessonNumber) * 2; // Unique request code
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                try {
                    alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                } catch (SecurityException e) {
                    Log.e("ScheduleManager", "Alarm permission issue", e);
                }

                // Schedule break notification if break duration is set
                int breakDuration = schoolLesson.getBreakDuration();
                if (breakDuration > 0) {
                    String[] endTimeParts = schoolLesson.getEndTime().split(":");
                    int endHour = Integer.parseInt(endTimeParts[0]);
                    int endMinute = Integer.parseInt(endTimeParts[1]);

                    Calendar breakStartTime = Calendar.getInstance();
                    breakStartTime.set(Calendar.DAY_OF_WEEK, day == 1 ? Calendar.SUNDAY : day);
                    breakStartTime.set(Calendar.HOUR_OF_DAY, endHour);
                    breakStartTime.set(Calendar.MINUTE, endMinute);
                    breakStartTime.set(Calendar.SECOND, 0);
                    breakStartTime.set(Calendar.MILLISECOND, 0);

                    if (breakStartTime.getTimeInMillis() < System.currentTimeMillis()) {
                        breakStartTime.add(Calendar.DAY_OF_YEAR, 7);
                    }

                    Intent breakIntent = new Intent(context, NotificationReceiver.class);
                    breakIntent.putExtra("notification_type", "break");
                    breakIntent.putExtra("lesson_number", lessonNumber);
                    breakIntent.putExtra("break_duration", breakDuration);
                    breakIntent.putExtra("user_type", userType);
                    breakIntent.putExtra("ringtone_uri", dbHelper.getSettings("ringtone_uri", null));

                    int breakRequestCode = (day * 1000 + lessonNumber) * 2 + 1;
                    PendingIntent breakPendingIntent = PendingIntent.getBroadcast(
                            context, breakRequestCode, breakIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                    try {
                        alarmManager.setExactAndAllowWhileIdle(
                                AlarmManager.RTC_WAKEUP, breakStartTime.getTimeInMillis(), breakPendingIntent);
                    } catch (SecurityException e) {
                        Log.e("ScheduleManager", "Alarm permission issue", e);
                    }
                }
            }
        }
    }
}
