package limor.tal.bells;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.List;

public class DashboardFragment extends Fragment {

    private SchoolDatabaseHelper db;
    private String userType;
    private int totalDays;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            db = ((MainActivity) getActivity()).getDbHelper();
        }
        if (getArguments() != null) {
            userType = getArguments().getString("userType", "student");
        }
        totalDays = Integer.parseInt(db.getSettings("total_days", "5"));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        Button menuButton = view.findViewById(R.id.menu_button);
        TableLayout scheduleTable = view.findViewById(R.id.schedule_table);

        // Set up menu
        menuButton.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(requireContext(), v);
            popupMenu.getMenu().add(0, 1, 0, "Edit Schedule");
            popupMenu.getMenu().add(0, 2, 0, "Advanced Settings");
            popupMenu.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) {
                    ScheduleFragment scheduleFragment = new ScheduleFragment();
                    Bundle args = new Bundle();
                    args.putInt("currentDay", 1);
                    args.putInt("totalDays", totalDays);
                    args.putString("userType", userType);
                    scheduleFragment.setArguments(args);
                    getParentFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, scheduleFragment)
                            .commit();
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).updateCurrentFragment(scheduleFragment);
                    }
                    return true;
                } else if (item.getItemId() == 2) {
                    AdvancedSettingsFragment settingsFragment = new AdvancedSettingsFragment();
                    getParentFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, settingsFragment)
                            .commit();
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).updateCurrentFragment(settingsFragment);
                    }
                    return true;
                }
                return false;
            });
            popupMenu.show();
        });

        // Build schedule table
        int maxLessons = getMaxLessons();
        // Header row
        TableRow headerRow = new TableRow(requireContext());
        TextView emptyHeader = new TextView(requireContext());
        emptyHeader.setText("");
        emptyHeader.setPadding(8, 8, 8, 8);
        headerRow.addView(emptyHeader);
        for (int day = 1; day <= totalDays; day++) {
            TextView dayHeader = new TextView(requireContext());
            dayHeader.setText("Day " + day);
            dayHeader.setTypeface(null, Typeface.BOLD);
            dayHeader.setPadding(8, 8, 8, 8);
            dayHeader.setGravity(Gravity.CENTER);
            dayHeader.setMaxWidth(200);
            dayHeader.setEllipsize(TextUtils.TruncateAt.END);
            headerRow.addView(dayHeader);
        }
        scheduleTable.addView(headerRow);

        // Lesson rows
        for (int lessonNum = 1; lessonNum <= maxLessons; lessonNum++) {
            TableRow lessonRow = new TableRow(requireContext());
            TextView lessonHeader = new TextView(requireContext());
            lessonHeader.setText("Lesson " + lessonNum);
            lessonHeader.setTypeface(null, Typeface.BOLD);
            lessonHeader.setPadding(8, 8, 8, 8);
            lessonHeader.setGravity(Gravity.CENTER);
            lessonRow.addView(lessonHeader);

            for (int day = 1; day <= totalDays; day++) {
                TextView lessonCell = new TextView(requireContext());
                StringBuilder cellText = new StringBuilder();
                List<Lesson> lessons = ScheduleManager.getLessonsForDay(db, day);
                for (Lesson lesson : lessons) {
                    if (lesson.getLessonNumber() == lessonNum) {
                        cellText.append(lesson.getSubject()).append("\n")
                                .append(lesson.getTeacherOrGroup()).append("\n")
                                .append(lesson.getBuilding()).append(" ").append(lesson.getRoom());
                        break;
                    }
                }

                // Add break duration
                List<SchoolLesson> schoolLessons = ScheduleManager.getSchoolLessons(db, day);
                for (SchoolLesson schoolLesson : schoolLessons) {
                    if (schoolLesson.getLessonNumber() == lessonNum && schoolLesson.getBreakDuration() > 0) {
                        if (cellText.length() > 0) {
                            cellText.append("\n");
                        }
                        cellText.append("Break: ").append(schoolLesson.getBreakDuration()).append(" min");
                    }
                }

                lessonCell.setText(cellText.toString());
                lessonCell.setPadding(8, 8, 8, 8);
                lessonCell.setGravity(Gravity.CENTER);
                lessonCell.setMaxWidth(200);
                lessonCell.setEllipsize(TextUtils.TruncateAt.END);
                lessonCell.setMaxLines(5);
                lessonRow.addView(lessonCell);
            }
            scheduleTable.addView(lessonRow);
        }

        return view;
    }

    private int getMaxLessons() {
        int maxLessons = 0;
        for (int day = 1; day <= totalDays; day++) {
            int lessonCount = ScheduleManager.getSchoolLessons(db, day).size();
            if (lessonCount > maxLessons) {
                maxLessons = lessonCount;
            }
        }
        return maxLessons > 0 ? maxLessons : 10;
    }
}
