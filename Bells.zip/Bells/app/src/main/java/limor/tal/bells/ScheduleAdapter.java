package limor.tal.bells;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.LessonViewHolder> {

    private List<Lesson> lessons;
    private Context context;
    private OnSpeechClickListener speechClickListener;
    private OnCameraClickListener cameraClickListener;
    private OnGalleryClickListener galleryClickListener;
    private RecyclerView recyclerView;

    public interface OnSpeechClickListener {
        void onSpeechClick(int position);
    }

    public interface OnCameraClickListener {
        void onCameraClick(int position);
    }

    public interface OnGalleryClickListener {
        void onGalleryClick(int position);
    }

    public ScheduleAdapter(Context context, List<Lesson> lessons, OnSpeechClickListener speechClickListener,
                           OnCameraClickListener cameraClickListener, OnGalleryClickListener galleryClickListener) {
        this.context = context;
        this.lessons = lessons;
        this.speechClickListener = speechClickListener;
        this.cameraClickListener = cameraClickListener;
        this.galleryClickListener = galleryClickListener;
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.recyclerView = recyclerView;
    }

    @NonNull
    @Override
    public LessonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_schedule, parent, false);
        return new LessonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LessonViewHolder holder, int position) {
        Lesson lesson = lessons.get(position);
        holder.lessonTitle.setText("Lesson " + lesson.getLessonNumber());

        // Set up subject spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                context, R.array.school_subjects, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.subjectSpinner.setAdapter(adapter);
        if (!lesson.getSubject().isEmpty()) {
            int spinnerPosition = adapter.getPosition(lesson.getSubject());
            holder.subjectSpinner.setSelection(spinnerPosition >= 0 ? spinnerPosition : 0);
        }

        holder.teacherOrGroupInput.setText(lesson.getTeacherOrGroup());
        holder.buildingInput.setText(lesson.getBuilding());
        holder.roomInput.setText(lesson.getRoom());

        // Display photo if exists
        if (lesson.getPhoto() != null) {
            holder.photoView.setImageBitmap(lesson.getPhoto());
            holder.photoView.setVisibility(View.VISIBLE);
        } else {
            holder.photoView.setVisibility(View.GONE);
        }

        holder.speechButton.setOnClickListener(v -> speechClickListener.onSpeechClick(position));
        holder.cameraButton.setOnClickListener(v -> cameraClickListener.onCameraClick(position));
        holder.galleryButton.setOnClickListener(v -> galleryClickListener.onGalleryClick(position));
    }

    @Override
    public int getItemCount() {
        return lessons.size();
    }

    public List<Lesson> getLessons() {
        for (int i = 0; i < lessons.size(); i++) {
            LessonViewHolder holder = getViewHolderByPosition(i);
            if (holder != null) {
                Lesson lesson = lessons.get(i);
                lesson.setSubject(holder.subjectSpinner.getSelectedItem() != null ? holder.subjectSpinner.getSelectedItem().toString() : "");
                lesson.setTeacherOrGroup(holder.teacherOrGroupInput.getText().toString().trim());
                lesson.setBuilding(holder.buildingInput.getText().toString().trim());
                lesson.setRoom(holder.roomInput.getText().toString().trim());
            }
        }
        return lessons;
    }

    public void updatePhoto(int position, Bitmap photo) {
        if (position >= 0 && position < lessons.size()) {
            lessons.get(position).setPhoto(photo);
            notifyItemChanged(position);
        }
    }

    private LessonViewHolder getViewHolderByPosition(int position) {
        if (recyclerView != null) {
            RecyclerView.ViewHolder holder = recyclerView.findViewHolderForAdapterPosition(position);
            if (holder instanceof LessonViewHolder) {
                return (LessonViewHolder) holder;
            }
        }
        return null;
    }

    static class LessonViewHolder extends RecyclerView.ViewHolder {
        TextView lessonTitle;
        Spinner subjectSpinner;
        EditText teacherOrGroupInput;
        Button speechButton;
        EditText buildingInput;
        EditText roomInput;
        ImageView photoView;
        Button cameraButton;
        Button galleryButton;

        LessonViewHolder(@NonNull View itemView) {
            super(itemView);
            lessonTitle = itemView.findViewById(R.id.lesson_title);
            subjectSpinner = itemView.findViewById(R.id.subject_spinner);
            teacherOrGroupInput = itemView.findViewById(R.id.teacher_or_group_input);
            speechButton = itemView.findViewById(R.id.speech_button);
            buildingInput = itemView.findViewById(R.id.building_input);
            roomInput = itemView.findViewById(R.id.room_input);
            photoView = itemView.findViewById(R.id.photo_view);
            cameraButton = itemView.findViewById(R.id.camera_button);
            galleryButton = itemView.findViewById(R.id.gallery_button);
        }
    }
}
