package limor.tal.bells;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ScheduleFragment extends Fragment {

    private SchoolDatabaseHelper dbHelper;
    private int currentDay;
    private int totalDays;
    private String userType;
    private static final String[] DAY_NAMES = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private ActivityResultLauncher<Intent> photoPickerLauncher;
    private int currentLessonForPhoto;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            dbHelper = ((MainActivity) getActivity()).getDbHelper();
        }
        if (getArguments() != null) {
            currentDay = getArguments().getInt("currentDay", 1);
            totalDays = getArguments().getInt("totalDays", 5);
            userType = getArguments().getString("userType", "student");
        }

        // Initialize photo picker launcher
        photoPickerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                Uri photoUri = result.getData().getData();
                if (photoUri != null) {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), photoUri);
                        setTeacherPhotoForLesson(currentLessonForPhoto, bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);

        TextView currentDayTextView = view.findViewById(R.id.current_day_text_view);
        EditText teacherGroupInput = view.findViewById(R.id.teacher_group_input);
        LinearLayout lessonContainer = view.findViewById(R.id.lesson_container);

        // Set current day indication
        String dayName = currentDay <= DAY_NAMES.length ? DAY_NAMES[currentDay - 1] : "Day " + currentDay;
        currentDayTextView.setText("Editing Schedule for " + dayName);

        // Load saved teacher/group
        String savedTeacherGroup = dbHelper.getSettings("day_" + currentDay + "_teacher_group", "");
        teacherGroupInput.setText(savedTeacherGroup);

        // Clear existing views to prevent duplicates
        lessonContainer.removeAllViews();

        // Add lesson inputs (1–9)
        for (int i = 1; i <= 9; i++) {
            View lessonRow = inflater.inflate(R.layout.lesson_row, lessonContainer, false);

            TextView lessonLabel = lessonRow.findViewById(R.id.lesson_label);
            Spinner subjectSpinner = lessonRow.findViewById(R.id.subject_spinner);
            ImageView teacherPhoto = lessonRow.findViewById(R.id.teacher_photo);
            Button setPhotoButton = lessonRow.findViewById(R.id.set_photo_button);

            lessonLabel.setText(String.valueOf(i));
            subjectSpinner.setTag(i);

            // Set up subject spinner
            ArrayAdapter<CharSequence> subjectAdapter = ArrayAdapter.createFromResource(
                    requireContext(), R.array.school_subjects, android.R.layout.simple_spinner_item);
            subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            subjectSpinner.setAdapter(subjectAdapter);

            // Load saved subject
            String savedSubject = dbHelper.getSettings("day_" + currentDay + "_lesson_" + i + "_subject", "Other");
            subjectSpinner.setSelection(subjectAdapter.getPosition(savedSubject));

            // Load saved teacher photo
            String savedPhotoPath = dbHelper.getSettings("day_" + currentDay + "_lesson_" + i + "_teacher_photo", "");
            if (!savedPhotoPath.isEmpty()) {
                Bitmap bitmap = BitmapFactory.decodeFile(savedPhotoPath);
                if (bitmap != null) {
                    teacherPhoto.setImageBitmap(bitmap);
                }
            }

            // Set photo button listener
            final int lesson = i;
            setPhotoButton.setOnClickListener(v -> {
                currentLessonForPhoto = lesson;
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                photoPickerLauncher.launch(intent);
            });

            lessonContainer.addView(lessonRow);
        }

        return view;
    }

    @Override
    public void onPause() {
        super.onPause();
        // Save subjects and teacher/group
        LinearLayout lessonContainer = getView().findViewById(R.id.lesson_container);
        EditText teacherGroupInput = getView().findViewById(R.id.teacher_group_input);
        String teacherGroup = teacherGroupInput.getText().toString().trim();
        dbHelper.saveSettings("day_" + currentDay + "_teacher_group", teacherGroup);

        if (lessonContainer != null) {
            for (int i = 1; i <= Math.min(9, lessonContainer.getChildCount()); i++) {
                LinearLayout lessonRow = (LinearLayout) lessonContainer.getChildAt(i - 1);
                Spinner subjectSpinner = lessonRow.findViewById(R.id.subject_spinner);
                String subject = subjectSpinner.getSelectedItem().toString();
                dbHelper.saveSettings("day_" + currentDay + "_lesson_" + i + "_subject", subject);
            }
        }
    }

    public void setSpeechResult(String speechResult) {
        if (getView() == null) return;

        EditText teacherGroupInput = getView().findViewById(R.id.teacher_group_input);
        teacherGroupInput.setText(speechResult);
        dbHelper.saveSettings("day_" + currentDay + "_teacher_group", speechResult.trim());
    }

    public void setTeacherPhotoForLesson(int lesson, Bitmap bitmap) {
        if (getView() == null || lesson < 1 || lesson > 9 || bitmap == null) return;

        LinearLayout lessonContainer = getView().findViewById(R.id.lesson_container);
        if (lessonContainer == null || lessonContainer.getChildCount() < lesson) {
            return; // Prevent IndexOutOfBoundsException
        }

        LinearLayout lessonRow = (LinearLayout) lessonContainer.getChildAt(lesson - 1);
        ImageView teacherPhoto = lessonRow.findViewById(R.id.teacher_photo);

        if (teacherPhoto == null) {
            return; // Prevent NullPointerException
        }

        try {
            // Set bitmap to ImageView
            teacherPhoto.setImageBitmap(bitmap);

            // Save bitmap to internal storage
            String fileName = "teacher_photo_day_" + currentDay + "_lesson_" + lesson + ".png";
            File file = new File(requireContext().getFilesDir(), fileName);
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            }

            // Save file path to database
            dbHelper.saveSettings("day_" + currentDay + "_lesson_" + lesson + "_teacher_photo", file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
