package limor.tal.bells;

import android.app.Activity;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AdvancedSettingsFragment extends Fragment {

    private SchoolDatabaseHelper dbHelper;
    private ActivityResultLauncher<Intent> ringtonePickerLauncher;
    private TextView ringtoneNameTextView;
    private EditText notification1MinInput;
    private EditText notification3MinInput;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            dbHelper = ((MainActivity) getActivity()).getDbHelper();
        }

        ringtonePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri ringtoneUri = result.getData().getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                        if (ringtoneUri != null) {
                            dbHelper.saveSettings("ringtone_uri", ringtoneUri.toString());
                            updateRingtoneName(ringtoneUri);
                        }
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_advanced_settings, container, false);

        ringtoneNameTextView = view.findViewById(R.id.ringtone_name_text_view);
        Button selectRingtoneButton = view.findViewById(R.id.select_ringtone_button);
        Button backButton = view.findViewById(R.id.back_button);
        notification1MinInput = view.findViewById(R.id.notification_1min_input);
        notification3MinInput = view.findViewById(R.id.notification_3min_input);

        // Load current settings
        String ringtoneUriStr = dbHelper.getSettings("ringtone_uri", null);
        if (ringtoneUriStr != null) {
            updateRingtoneName(Uri.parse(ringtoneUriStr));
        } else {
            ringtoneNameTextView.setText("Default");
        }

        String notification1Min = dbHelper.getSettings("notification_1min", "1");
        String notification3Min = dbHelper.getSettings("notification_3min", "3");
        notification1MinInput.setText(notification1Min);
        notification3MinInput.setText(notification3Min);

        // Back button
        backButton.setOnClickListener(v -> {
            if (getActivity() != null) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        // Ringtone selection
        selectRingtoneButton.setOnClickListener(v -> {
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Notification Sound");
            String existingRingtone = dbHelper.getSettings("ringtone_uri", null);
            if (existingRingtone != null) {
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existingRingtone));
            }
            ringtonePickerLauncher.launch(intent);
        });

        // Save notification settings on focus change
        notification1MinInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String value = notification1MinInput.getText().toString().trim();
                dbHelper.saveSettings("notification_1min", value.isEmpty() ? "1" : value);
            }
        });

        notification3MinInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String value = notification3MinInput.getText().toString().trim();
                dbHelper.saveSettings("notification_3min", value.isEmpty() ? "3" : value);
            }
        });

        return view;
    }

    private void updateRingtoneName(Uri ringtoneUri) {
        try {
            Ringtone ringtone = RingtoneManager.getRingtone(requireContext(), ringtoneUri);
            String name = ringtone != null ? ringtone.getTitle(requireContext()) : "Unknown";
            ringtoneNameTextView.setText(name);
        } catch (Exception e) {
            ringtoneNameTextView.setText("Error");
        }
    }
}
