package limor.tal.bells;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;

public class DashboardFragment extends Fragment {

    private SchoolDatabaseHelper dbHelper;
    private static final String[] DAY_NAMES = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private String userType;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            dbHelper = ((MainActivity) getActivity()).getDbHelper();
        }
        if (getArguments() != null) {
            userType = getArguments().getString("userType", "student");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        TextView currentClassTextView = view.findViewById(R.id.current_class_text_view);
        TextView nextClassTextView = view.findViewById(R.id.next_class_text_view);
        ImageView currentClassPhoto = view.findViewById(R.id.current_class_photo);
        ImageView nextClassPhoto = view.findViewById(R.id.next_class_photo);
        RecyclerView recyclerView = view.findViewById(R.id.schedule_recycler_view);

        // Get total days
        String totalDaysStr = dbHelper.getSettings("total_days", "5");
        int totalDays = Integer.parseInt(totalDaysStr);

        // Set current and next class with photos
        setCurrentAndNextClass(currentClassTextView, nextClassTextView, currentClassPhoto, nextClassPhoto, totalDays);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false));
        ScheduleAdapter adapter = new ScheduleAdapter(totalDays, userType, dbHelper);
        recyclerView.setAdapter(adapter);

        return view;
    }

    private void setCurrentAndNextClass(TextView currentClassTextView, TextView nextClassTextView,
                                        ImageView currentClassPhoto, ImageView nextClassPhoto, int totalDays) {
        Calendar now = Calendar.getInstance();
        int currentHour = now.get(Calendar.HOUR_OF_DAY);
        int currentMinute = now.get(Calendar.MINUTE);
        int dayOfWeek = now.get(Calendar.DAY_OF_WEEK); // 1=Sunday, 2=Monday, etc.
        int currentDay = Math.min(dayOfWeek, totalDays);

        String currentClass = "None";
        String nextClass = "None";
        String currentPhotoPath = "";
        String nextPhotoPath = "";

        // Find current class
        for (int lesson = 1; lesson <= 9; lesson++) {
            String startHourStr = dbHelper.getSettings("lesson_" + lesson + "_start_hour", "0");
            String startMinuteStr = dbHelper.getSettings("lesson_" + lesson + "_start_minute", "0");
            String endHourStr = dbHelper.getSettings("lesson_" + lesson + "_end_hour", "0");
            String endMinuteStr = dbHelper.getSettings("lesson_" + lesson + "_end_minute", "0");

            int startHour = Integer.parseInt(startHourStr);
            int startMinute = Integer.parseInt(startMinuteStr);
            int endHour = Integer.parseInt(endHourStr);
            int endMinute = Integer.parseInt(endMinuteStr);

            int startTime = startHour * 60 + startMinute;
            int endTime = endHour * 60 + endMinute;
            int currentTime = currentHour * 60 + currentMinute;

            if (currentTime >= startTime && currentTime < endTime) {
                String subject = dbHelper.getSettings("day_" + currentDay + "_lesson_" + lesson + "_subject", "-");
                String time = String.format("%s:%s–%s:%s", startHourStr, startMinuteStr, endHourStr, endMinuteStr);
                currentClass = lesson + " (" + subject + ", " + time + ")";
                currentPhotoPath = dbHelper.getSettings("day_" + currentDay + "_lesson_" + lesson + "_teacher_photo", "");

                // Look for next class
                if (lesson < 9) {
                    String nextSubject = dbHelper.getSettings("day_" + currentDay + "_lesson_" + (lesson + 1) + "_subject", "-");
                    String nextStartHour = dbHelper.getSettings("lesson_" + (lesson + 1) + "_start_hour", "0");
                    String nextStartMinute = dbHelper.getSettings("lesson_" + (lesson + 1) + "_start_minute", "0");
                    String nextEndHour = dbHelper.getSettings("lesson_" + (lesson + 1) + "_end_hour", "0");
                    String nextEndMinute = dbHelper.getSettings("lesson_" + (lesson + 1) + "_end_minute", "0");
                    String nextTime = String.format("%s:%s–%s:%s", nextStartHour, nextStartMinute, nextEndHour, nextEndMinute);
                    nextClass = (lesson + 1) + " (" + nextSubject + ", " + nextTime + ")";
                    nextPhotoPath = dbHelper.getSettings("day_" + currentDay + "_lesson_" + (lesson + 1) + "_teacher_photo", "");
                } else if (currentDay < totalDays) {
                    String nextSubject = dbHelper.getSettings("day_" + (currentDay + 1) + "_lesson_1_subject", "-");
                    String nextTime = String.format("%s:%s–%s:%s",
                            dbHelper.getSettings("lesson_1_start_hour", "0"),
                            dbHelper.getSettings("lesson_1_start_minute", "0"),
                            dbHelper.getSettings("lesson_1_end_hour", "0"),
                            dbHelper.getSettings("lesson_1_end_minute", "0"));
                    nextClass = "1 (" + nextSubject + ", " + nextTime + ")";
                    nextPhotoPath = dbHelper.getSettings("day_" + (currentDay + 1) + "_lesson_1_teacher_photo", "");
                }
                break;
            }
        }

        currentClassTextView.setText("Current Class: " + currentClass);
        nextClassTextView.setText("Next Class: " + nextClass);

        // Show teacher photos in student mode
        if ("student".equals(userType)) {
            if (!currentPhotoPath.isEmpty()) {
                Bitmap bitmap = BitmapFactory.decodeFile(currentPhotoPath);
                if (bitmap != null) {
                    currentClassPhoto.setImageBitmap(bitmap);
                    currentClassPhoto.setVisibility(View.VISIBLE);
                }
            }
            if (!nextPhotoPath.isEmpty()) {
                Bitmap bitmap = BitmapFactory.decodeFile(nextPhotoPath);
                if (bitmap != null) {
                    nextClassPhoto.setImageBitmap(bitmap);
                    nextClassPhoto.setVisibility(View.VISIBLE);
                }
            }
        }
    }
}